import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
df = pd.read_csv('studentsperformance.csv')
print("Dataset loaded successfully.")
#print("'studentsperformance.csv' not found. Creating mock data for testing...")
data = {
             'maths':[56,75,97],
             'physics':[58,80,95],
             'chemistry':[65,68,64]
             }
                       

        #'math score': [72, 69, 90, 47, 76, 88, 55, 62, 79, 95],
        #'reading score': [72, 90, 95, 57, 78, 85, 60, 65, 80, 92],
        #'writing score': [74, 88, 93, 44, 75, 86, 58, 64, 82, 94]
    
df = pd.DataFrame(data)
subjects = ['maths', 'physics', 'chemistry']
print("\n--- Statistics Per Subject ---")
stats = df[subjects].agg(['mean', 'max', 'min'])
print(stats)
num_students = 3
subset = df.head(num_students)
x = np.arange(num_students)
width = 0.25
plt.figure(figsize=(10, 6))
# Plotting each subject with a distinct color
plt.bar(x - width, subset['maths'], width, label='Math', color='#1f77b4')
plt.bar(x, subset['physics'], width, label='physics', color='#ff7f0e')
plt.bar(x + width, subset['chemistry'], width, label='chemistry', color='#2ca02c')
plt.ylabel('Scores')
plt.title(f'Comparison of Marks for First {num_students} Students')
plt.xticks(x, [f'Student {i+1}' for i in range(num_students)])
plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()
